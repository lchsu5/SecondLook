I will implement the **Bear 1** token compression pipeline to optimize the data flow between OCR and the LLM.

### **Architecture Changes**
Currently, the app uses a single monolithic VLM (Overshoot) for both OCR and reasoning. To "cut down tokens," I will split this into a 3-step pipeline:
1.  **OCR Step**: Use Overshoot purely for video-to-text transcription (using a cheaper/faster prompt).
2.  **Compression Step**: Send the raw transcription to **The Token Company (Bear 1)** to reduce token count.
3.  **Reasoning Step**: Send the compressed text to an LLM (Google Gemini, as `@google/generative-ai` is installed) to generate the feedback.

### **Implementation Steps**

1.  **Create `src/lib/bear.js`**
    *   Implement `BearClient` to interact with The Token Company API.
    *   Endpoint: `https://api.thetokencompany.com/v1/compress` (derived from docs URL).
    *   Use `VITE_TTC_API_KEY` for authentication.

2.  **Create `src/lib/llm.js`**
    *   Implement `GeminiClient` using the installed `@google/generative-ai` package.
    *   This will replace the "reasoning" part that Overshoot was doing.
    *   *Note: This requires a Google API Key. I will add a placeholder to `.env`.*

3.  **Modify `src/lib/overshoot.js`**
    *   Add a new prompt `MathTutorPrompts.transcriptionOnly` that instructs the model to *only* extract text/math without analyzing it, saving generation tokens.

4.  **Update `src/App.jsx`**
    *   Change the stream initialization to use the `transcriptionOnly` prompt.
    *   In the `onResult` callback:
        *   Capture the raw transcription.
        *   **Await** `BearClient.compress(transcription)`.
        *   **Await** `GeminiClient.analyze(compressedText)`.
        *   Update the UI with the final feedback.

### **Verification Plan**
*   **API Check**: Ensure `.env` has all necessary keys (`VITE_TTC_API_KEY`, `VITE_OVERSHOOT_API_KEY`, `VITE_GOOGLE_API_KEY`).
*   **Flow Test**: Verify that text appears in the "OCR Debug" panel (Step 1), passes through compression (Step 2), and generates feedback cards (Step 3).
